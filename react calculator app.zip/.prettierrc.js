module.exports = {
    endOfLine: 'lf',
    singleQuote: true,
    trailingComma: 'all',
    printWidth: 100,
  };